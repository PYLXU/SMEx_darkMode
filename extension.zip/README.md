# SMEx_darkMode

[SimMusic扩展]适用于 SimMusic 的 主界面深色模式 扩展

## 扩展截图

![696bdd3dab7b53b687099ff16707ea84](https://github.com/user-attachments/assets/c0c5f55b-f014-4e93-8cf1-dd7bf8d3ba24)
![8e08c2442e878d3a93db4d390ff85d2e](https://github.com/user-attachments/assets/5d81c393-cbd7-4d92-97fe-57a0715570b6)
![79105429f4de0835e1c5649552e58216](https://github.com/user-attachments/assets/8827bc0f-b6e6-41f6-a385-49845f637576)
![1c82675d2d566847f7b28f6c1f7eed4b](https://github.com/user-attachments/assets/2698bc26-fa28-4c04-a496-7d819ad38a6f)
![116159a02f21d92a64cc76124e879356](https://github.com/user-attachments/assets/f799a02d-f29e-47ec-82a0-f93f9d464921)
![493746992296e7b0d3fa241a6f803797](https://github.com/user-attachments/assets/b9667a80-68f8-4142-b433-ccf96d956cd2)
![50508ef8bf32171093234056a18c842c](https://github.com/user-attachments/assets/0633a286-a49d-4521-802f-86d7b4bec558)
![5696b9515b24416d9f01c3ef393ea2b9](https://github.com/user-attachments/assets/a1ef1714-4abb-43f7-9304-434387bb859b)
![71b959c907aa89dfcf1e0f17e40215f6](https://github.com/user-attachments/assets/42f2ccc4-a204-469d-94fd-39dc69126d08)


## 安装教程

### 方式：直接安装

1. 下载此扩展到任意位置
2. 安装SimMusic后，打开「扩展」页面，将此扩展拖入扩展页面后点击「确认」按钮安装

## 扩展说明

1. 若扩展存在Bug请及时[提交](https://github.com/PYLXU/SMEx_darkMode/issues)，非常感谢
2. 非主界面暂时没法适配，主界面功能几乎全部实现完毕
3. 启用本扩展时请同时启用内置的“播放页深色模式”

## 特别鸣谢

- SimMusic为本扩展提供开发平台
